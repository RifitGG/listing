package glava7;

import java.io.BufferedReader;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class GrepInputStream extends FilterInputStream {
    private String substring; // образец для поиска
    private BufferedReader br;

    public GrepInputStream(InputStream in, String substring) {
        super(in);
        this.br = new BufferedReader(new InputStreamReader(in));
        this.substring = substring;
    }

    public String readLine() throws IOException {
        String line;
        do {
            line = br.readLine();
        } while ((line != null) && !line.contains(substring));
        return line;
    }
}
