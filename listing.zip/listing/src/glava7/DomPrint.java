package glava7;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

class DomPrint {
    // Вывод отступа для разделения уровней
    private static void printIndentation(int level) {
        for (int i = 0; i < level; i++) {
            System.out.print("   ");
        }
    }

    // Печать содержимого узла
    private static void print(Node node, int level) {
        if (level > 0) {
            System.out.println();
            printIndentation(level);
        }
        System.out.println(node.getNodeName() + ":");

        if (node.hasAttributes()) {
            NamedNodeMap attributes = node.getAttributes();
            if (attributes.getLength() > 0) {
                level++;
                for (int i = 0; i < attributes.getLength(); i++) {
                    Node attribute = attributes.item(i);
                    printIndentation(level);
                    System.out.println("." + attribute.getNodeName() + "=" + attribute.getNodeValue());
                }
                level--;
            }
        }

        String value = node.getNodeValue();
        value = (value == null ? "" : value.trim());
        if (value.length() > 0) {
            printIndentation(level);
            System.out.println(value);
        }

        if (node.hasChildNodes()) {
            level++;
            NodeList children = node.getChildNodes();
            for (int i = 0; i < children.getLength(); i++) {
                Node child = children.item(i);
                print(child, level);
            }
            level--;
        }
    }

    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Usage: java glava7.DomPrint <имя_файла_xml>");
            return;
        }
        File docFile = new File(args[0]);
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setIgnoringComments(true);
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(docFile);
            print(doc.getDocumentElement(), 0);
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
}
