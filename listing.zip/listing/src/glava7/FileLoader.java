package glava7;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class FileLoader {

    public static byte[] readFile(String filePath) throws IOException {
        File file = new File(filePath);
        if (file.length() > Integer.MAX_VALUE) {
            throw new IOException("Файл " + file.getName() + " слишком длинный!");
        }

        try (InputStream is = new FileInputStream(file)) {
            // Создание массива для содержимого файла
            byte[] bytes = new byte[(int) file.length()];

            // Чтение байтов
            int offset = 0;
            int numRead;
            while (offset < bytes.length && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0) {
                offset += numRead;
            }

            // Проверка, пройден ли файл до конца
            if (offset < bytes.length) {
                throw new IOException("Не удалось прочитать файл " + file.getName() + " целиком.");
            }

            return bytes;
        }
    }
}
