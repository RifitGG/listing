package glava7;

import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

class SaxPrint extends DefaultHandler {
    // Реализация методов-обработчиков событий, объявленных в классе DefaultHandler

    @Override
    public void startDocument() throws SAXException {
        System.out.println("Начало документа");
    }

    @Override
    public void endDocument() throws SAXException {
        System.out.println("Конец документа");
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        System.out.println("Начало элемента: " + qName);
        if (attributes.getLength() > 0) {
            for (int i = 0; i < attributes.getLength(); i++) {
                System.out.println(" . " + attributes.getQName(i) + "=" + attributes.getValue(i));
            }
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        System.out.println("Конец элемента: " + qName);
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        String content = new String(ch, start, length).trim();
        if (content.length() > 0) {
            System.out.println(" " + content);
        }
    }

    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Использование: java glava7.SaxPrint <имя_файла_xml>");
            return;
        }
        File docFile = new File(args[0]);
        try {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser parser = factory.newSAXParser();
            parser.parse(docFile, new SaxPrint());
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
}
