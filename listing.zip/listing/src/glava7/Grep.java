package glava7;

import java.io.FileInputStream;
import java.io.IOException;

public class Grep {
    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Usage: java glava7.Grep <образец> <имя_файла>");
            System.exit(1);
        }

        try {
            FileInputStream fis = new FileInputStream(args[1]);
            GrepInputStream gis = new GrepInputStream(fis, args[0]);

            String line;
            while ((line = gis.readLine()) != null) {
                System.out.println(line);
            }
            gis.close();
        } catch (IOException ioe) {
            System.err.println(ioe.getMessage());
        }
    }
}
