package glava7;

import java.io.*;
import java.util.zip.*;

class ZipDir {
    public static void exec(String zipFileName, String zippedDirPath)
            throws FileNotFoundException, IOException {
        ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFileName));
        walkingDir(zos, zippedDirPath, zippedDirPath);
        zos.close();
    }

    public static void walkingDir(ZipOutputStream zos, String folderPath, String baseFolderPath)
            throws FileNotFoundException, IOException {
        File folder = new File(folderPath);
        String[] fileList = folder.list();

        for (int i = 0; i < fileList.length; i++) {
            File f = new File(folder, fileList[i]);
            if (f.isDirectory()) {
                walkingDir(zos, f.getPath(), baseFolderPath);
                continue;
            } else {
                byte[] readBuffer = new byte[2048];
                int bytesRead;
                String fullPath = f.getPath();
                String relativePath = fullPath.substring(baseFolderPath.length() + 1);
                System.out.println("\tАрхивируется: " + fullPath);
                FileInputStream fis = new FileInputStream(fullPath);
                ZipEntry ze = new ZipEntry(relativePath);
                zos.putNextEntry(ze);
                while ((bytesRead = fis.read(readBuffer)) != -1) {
                    zos.write(readBuffer, 0, bytesRead);
                }
                fis.close();
            }
        }
    }
}

public class ZipDirTest {
    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Usage: java glava7.ZipDirTest <имя_архива> <имя_папки>");
            return;
        }
        String zipFileName = args[0];
        String zippedDirPath = args[1];
        try {
            System.out.println("Начало архивации папки: " + zippedDirPath);
            ZipDir.exec(zipFileName, zippedDirPath);
            System.out.println("Архив был записан успешно: " + zipFileName);
        } catch (FileNotFoundException fnfe) {
            System.out.println(fnfe.getMessage());
        } catch (IOException ioe) {
            System.out.println(ioe.getMessage());
        }
    }
}
