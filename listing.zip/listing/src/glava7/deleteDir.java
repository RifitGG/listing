package glava7;

import java.io.File;

public class deleteDir {
    public static void deleteDir(String dirPath) {
        File walkDir = new File(dirPath); // удаляемая папка
        String[] dirList = walkDir.list(); // список элементов в папке

        if (dirList != null) {
            for (int i = 0; i < dirList.length; i++) {
                File f = new File(walkDir, dirList[i]);
                if (f.isDirectory()) {
                    // если текущий элемент - папка
                    deleteDir(f.getPath());
                } else {
                    // текущий элемент - файл или уже пустая папка
                    f.delete();
                }
            }
        }
        walkDir.delete(); // удаляем корневую папку
    }
}
