package glava7;

import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.File;

public class Transform {
    public static void main(String[] args) {
        // Утилита принимает два параметра:
        // имя XML-файла и имя файла с таблицей стилей XSL
        if (args.length < 2) {
            System.out.println("Использование: java glava7.Transform имя_файла_xml имя_файла_xsl");
            System.exit(0);
        }
        File xslFile = new File(args[1]); // XSL-таблица
        File xmlFile = new File(args[0]); // исходный XML-документ

        // Создание входных и выходного потока
        StreamSource xslSource = new StreamSource(xslFile);
        StreamSource xmlSource = new StreamSource(xmlFile);
        StreamResult outResult = new StreamResult(System.out);

        try {
            // Получение фабрики и трансформатора
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer(xslSource);

            // Трансформация XML-документа
            transformer.transform(xmlSource, outResult);
        } catch (Exception ex) {
            System.out.println(ex);
        }
    } // main(String[]) method
} // glava7.Transform class
