package glava2;

public class CharArithDemo {
    public static void main(String[] args) {
        char ch;
        ch = 'L';
        System.out.println("ch равно " + ch);
        ch++; // Увеличиваем значение ch на 1
        System.out.println("Значение ch изменилось на " + ch);
        ch = 'д'; // Присваиваем ch значение 'д'
        ch--; // Уменьшаем значение ch на 1
        System.out.println("Значение ch снова изменилось и равно " + ch);
    } // main(String[]) method
} // CharArithDemo class
