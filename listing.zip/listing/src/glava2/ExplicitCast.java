package glava2;

public class ExplicitCast {
    public static void main(String[] args) {
        long l = 10; // Исправлено: '1' на 'l' (маленькая буква L)
        double a = l; // неявное приведение (long в double)
        l = (long) a; // явное приведение (double в long)
    } // main(String[]) method
} // ExplicitCast class
