package glava2;

public class IfStatementDemo {
    public static void main(String[] args) {
        int a, b, c, d;
        a = 2;
        b = 3;
        System.out.println("a равно " + a + ", b равно " + b);
        if (a < b) System.out.println("a меньше b");
        // Удалена неправильная строка, которая не будет выполнена
        System.out.println();
        c = a - b; // c будет равно -1
        System.out.println("c равно " + c);
        if (c >= 0) System.out.println("c имеет положительное значение");
        if (c < 0) System.out.println("c имеет отрицательное значение");
        System.out.println();
        d = b - a; // d равно 1
        System.out.println("d равно " + d);
        if (d >= 0) System.out.println("d имеет положительное значение");
        // Удалена неправильная проверка и закрывающая скобка
        System.out.println();
        // Исправлены опечатки в методах println
        if (a + c != b) System.out.println("a плюс c не равняется b");
        if (a + d == b) System.out.println("a плюс d равняется b");
    }
}
