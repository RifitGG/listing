package glava2;

public class StrDemo {
    public static void main(String[] args) {
        // для перевода каретки (начала новой строки)
        // служит код \n
        System.out.println("Первая строка\nВторая строка");
        // знак табуляции помогает оформить выводимый текст
        // в колонки. Он вводится с помощью кода \t
        System.out.println("A\tB\tC");
        System.out.println("D\tE\tF");
    } // main(String[]) method
} // StrDemo class
