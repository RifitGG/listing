package glava2;

public class AlphabetDoWhileDemo {
    public static void main(String[] args) {
        char ch = 'Я'; // Начальная точка: буква 'Я'
        do {
            System.out.println(ch);
            ch--;
        } while (ch >= 'А'); // Конечная точка: буква 'А'
    } // main(String[]) method
} // AlphabetDoWhileDemo class
