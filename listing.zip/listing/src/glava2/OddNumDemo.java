package glava2;

public class OddNumDemo {
    public static void main(String[] args) {
        for (int num = 0; num <= 10; num++) { // Исправлено: numtt+ на num++
            if ((num % 2) == 0) continue; // Исправлено: пом на num
            System.out.println(num); // Исправлено: добавлено точка с запятой
        }
    } // main(String[]) method
} // OddNumDemo class
