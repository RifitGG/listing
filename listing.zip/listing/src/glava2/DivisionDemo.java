package glava2;

public class DivisionDemo {
    public static void main(String[] args) {
        int iresult, iremain; // для деления целых чисел
        double dresult, dremain; // для деления вещественных чисел

        // деление целых чисел
        iresult = 10 / 3;
        iremain = 10 % 3;
        System.out.println("Частное от деления 10 / 3 равно " + iresult +
                ", остаток равен " + iremain);

        // деление вещественных чисел
        dresult = 10.0 / 3.0;
        dremain = 10.0 % 3.0;
        System.out.println("Частное от деления 10.0 / 3.0 равно " + dresult +
                ", остаток равен " + dremain);
    } // main(String[]) method
} // DivisionDemo class
