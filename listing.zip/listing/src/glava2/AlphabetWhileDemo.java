package glava2;

public class AlphabetWhileDemo {
    public static void main(String[] args) {
        char ch = 'a';
        while (ch <= 'z') {
            System.out.println(ch);
            ch++;
        } // while
    } // main(String[]) method
} // AlphabetWhileDemo class
