package glava2;

public class NestVar {
    public static void main(String[] args) {
        int count = 1;
        System.out.println("count = " + count);
        {
            int n = 3;
            System.out.println("Первый независимый блок: count = " + count + ", n = " + n);
        }
        {
            int n = 5; // Эта переменная n независима от переменной n в предыдущем блоке
            System.out.println("Второй независимый блок: n = " + n);
        }
    } // main(String[]) method
} // NestVar class
