package glava3;

// Класс Vehicle с полями и методом toString()
class Vehicle11 {
    int passengers; // количество пассажиров
    int wheels; // количество колес
    int maxspeed; // максимальная скорость
    double burnup; // расход топлива

    // Конструктор класса Vehicle
    Vehicle11(int p, int w, int m, double b) {
        passengers = p;
        wheels = w;
        maxspeed = m;
        burnup = b;
    }

    // Переопределенный метод toString()
    public String toString() {
        return "Vehicle(passengers=" + passengers + ";" +
                "wheels=" + wheels + ";" +
                "maxspeed=" + maxspeed + ";" +
                "burnup=" + burnup + ")";
    }
} // class Vehicle

// Класс Auto, наследующийся от класса Vehicle
class Auto extends Vehicle {
    boolean sunroof; // наличие люка

    // Конструктор класса Auto с одним параметром
    Auto(boolean sunroof) {
        super(4, 4, 200, 12); // Вызов конструктора суперкласса
        this.sunroof = sunroof;
    }

    // Конструктор класса Auto с пятью параметрами
    Auto(int p, int w, int m, double b, boolean sunroof) {
        super(p, w, m, b); // Вызов конструктора суперкласса
        this.sunroof = sunroof;
    }
} // class Auto

// Демонстрационный класс с методом main
class VehicleOverrideDemo {
    public static void main(String[] args) {
        Vehicle v = new Vehicle(2, 2, 100, 9);
        Auto a = new Auto(2, 4, 180, 12, true);

        System.out.println("Vehicle.toString(): " + v.toString());
        System.out.println("Auto.toString(): " + a.toString());
    } // main(String[]) method
} // VehicleOverrideDemo class
