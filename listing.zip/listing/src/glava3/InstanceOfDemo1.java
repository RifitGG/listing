package glava3;

// Интерфейс Moveable
interface Moveable {
    void move(int x, int y);
}

// Класс Vehicle
class Vehicle {
    @Override
    public String toString() {
        return "Это Vehicle";
    }
}

// Класс Auto, наследующийся от Vehicle и реализующий интерфейс Moveable
class Auto extends Vehicle implements Moveable {
    @Override
    public void move(int x, int y) {
        System.out.println("Auto двигается на " + x + ", " + y);
    }

    @Override
    public String toString() {
        return "Это Auto";
    }
}

// Демонстрационный класс InstanceOfDemo
public class InstanceOfDemo1 {
    public static void main(String[] args) {
        Auto a = new Auto();
        Vehicle v = new Vehicle();
        Vehicle[] va = {a, v};
        for (int i = 0; i < va.length; i++) {
            System.out.println(va[i].toString());
            if (va[i] instanceof Moveable) {
                Moveable m = (Moveable) va[i];
                m.move(10 + i * 34, 34);
            }
        } // for
    } // main(String[]) method
} // InstanceOfDemo class
