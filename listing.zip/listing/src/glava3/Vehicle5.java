package glava3;

class Vehicle5 {
    int passengers; // количество пассажиров
    int wheels; // число колес
    int maxspeed; // максимальная скорость
    int burnup; // расход топлива

    // Конструктор с параметрами
    Vehicle5(int p, int w, int ms, int bu) {
        passengers = p;
        wheels = w;
        maxspeed = ms;
        burnup = bu;
    } // Vehicle(int, int, int, int) конструктор

    // Расчет длины пройденного пути
    double distance(double interval) {
        double value = maxspeed * interval;
        return value;
    } // distance(double) метод
} // Vehicle класс

class VehicleConstrDemo {
    public static void main(String[] args) {
        Vehicle car = new Vehicle(2, 4, 130, 30);
        Vehicle bus = new Vehicle(45, 4, 120, 25);
        double interval = 1.0;
        double distanceCar = car.distance(interval);
        double distanceBus = bus.distance(interval);
        System.out.println("Автомобиль с " + car.passengers +
                " пассажирами проедет за 1 час " + distanceCar + " км.");
        System.out.println("Автобус с " + bus.passengers +
                " пассажирами проедет за 1 час " + distanceBus + " км.");
    } // main(String[]) метод
} // VehicleConstrDemo класс
