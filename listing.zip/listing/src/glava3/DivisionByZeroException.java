package glava3;

// Класс исключения для деления на ноль
class DivisionByZeroException extends Exception {
    public String getMessage() {
        return "Деление на ноль запрещено!";
    }
} // DivisionByZeroException class

// Класс для демонстрации обработки исключений
class ExceptionDemo {
    private static double divide(double dividend, double divisor) throws DivisionByZeroException {
        if (divisor == 0)
            throw new DivisionByZeroException();
        return dividend / divisor;
    } // divide() method

    public static void main(String[] args) {
        try {
            System.out.println(divide(8, 0));
        } catch (DivisionByZeroException dz) {
            System.out.println(dz.getMessage());
        }
    } // main(String[]) method
} // ExceptionDemo class
