package glava3;

// Абстрактный класс Shape
abstract class Shape {
    abstract double area(); // метод для вычисления площади
}

// Класс Point, наследующийся от Shape
class Point extends Shape {
    public String toString() {
        return "Точка";
    }

    double area() {
        return 0; // площадь точки равна 0
    }
}

// Класс Triangle, наследующийся от Shape
class Triangle extends Shape {
    int cathetus1; // первый катет
    int cathetus2; // второй катет

    Triangle(int cathetus1, int cathetus2) {
        this.cathetus1 = cathetus1;
        this.cathetus2 = cathetus2;
    }

    public String toString() {
        return "Треугольник";
    }

    double area() {
        return (cathetus1 * cathetus2) / 2.0; // формула площади треугольника
    }
}

// Класс Circle, наследующийся от Shape
class Circle extends Shape {
    int radius; // радиус

    Circle(int radius) {
        this.radius = radius;
    }

    public String toString() {
        return "Круг";
    }

    double area() {
        return (radius * radius) * Math.PI; // формула площади круга
    }
}

// Демонстрационный класс ShapeDemo
public class ShapeDemo {
    public static void main(String[] args) {
        Point p = new Point();
        Triangle t = new Triangle(5, 3);
        Circle c = new Circle(9);
        Shape[] shapes = {p, t, c}; // Исправлено имя массива

        System.out.println("Расчет площади фигур:");
        for (int i = 0; i < shapes.length; i++) {
            System.out.println(shapes[i].toString() + " : " + shapes[i].area());
        }
    }
}
