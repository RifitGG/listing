package glava3;

public class InstanceOfDemo {
}
