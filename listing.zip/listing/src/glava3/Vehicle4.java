package glava3;

class Vehicle4 {
    int passengers; // количество пассажиров
    int wheels; // количество колес
    int maxspeed; // максимальная скорость
    int burnup; // расход топлива

    // объявляем метод, вычисляющий пройденный путь
    // теперь он возвращает вычисленное значение типа double
    double distance(double interval) {
        double value = maxspeed * interval;
        return value;
    } // distance(double interval)
} // Vehicle class

class VehicleRetMethod {
    public static void main(String[] args) {
        Vehicle car = new Vehicle();
        car.passengers = 2;
        car.wheels = 4;
        car.maxspeed = 130;
        car.burnup = 30;

        // другой экземпляр класса Vehicle
        Vehicle bus = new Vehicle();
        bus.passengers = 45;
        bus.wheels = 4;
        bus.maxspeed = 100;
        bus.burnup = 25;

        // расчет пути, пройденного за 0.5 часа
        double time = 0.5;
        double distanceCar = car.distance(time);
        double distanceBus = bus.distance(time);

        System.out.print("Автомобиль с " + car.passengers + " пассажирами ");
        System.out.println("промчит за полчаса путь " + distanceCar + " км.");
        System.out.print("Автобус с " + bus.passengers + " пассажирами ");
        System.out.println("промчит за полчаса путь " + distanceBus + " км.");
    } // main(String[]) method
} // VehicleRetMethod class
