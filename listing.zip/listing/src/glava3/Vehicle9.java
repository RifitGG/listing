package glava3;

class Vehicle9 {
    int passengers; // количество пассажиров
    private int wheels; // число колес
    private int maxspeed; // максимальная скорость
    int burnup; // расход топлива

    // Конструктор без параметров
    Vehicle9() {
        this(4, 4, 160, 13);
    } // Vehicle() конструктор

    // Конструктор с параметрами
    Vehicle9(int passengers, int wheels, int maxspeed, int burnup) {
        this.passengers = passengers;
        this.wheels = wheels;
        this.maxspeed = maxspeed;
        this.burnup = burnup;
    } // Vehicle(int, int, int, int) конструктор

    // Методы расчета длины пройденного пути
    double distance(int interval) {
        return distance((double) interval);
    } // distance (int)

    double distance(double interval) {
        double value = this.maxspeed * interval;
        return value;
    } // distance (double)
} // Vehicle класс
