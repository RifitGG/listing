package glava3;

class Basket { // "корзина покупок"
    // Оплата наличными
    void pay(double money) {
        System.out.println("Оплачено наличными: " + money);
    }

    // Оплата кредитной картой
    void pay(String cardNum) {
        System.out.println("Оплачено по кредитной карте #" + cardNum);
    }

    // Оплата чеком
    void pay(String accountNum, String bankCode) {
        System.out.println("Переведено на счет #" + accountNum + " в банке " + bankCode);
    }
} // Basket класс

class BasketDemo {
    public static void main(String[] args) {
        Basket b1 = new Basket();
        Basket b2 = new Basket();
        Basket b3 = new Basket();
        System.out.print("b1: ");
        b1.pay(1200.0); // Оплата наличными
        System.out.print("b2: ");
        b2.pay("123456789"); // Оплата по карте
        System.out.print("b3: ");
        b3.pay("987654321", "5500"); // Оплата переводом
    } // main(String[]) метод
} // BasketDemo класс
