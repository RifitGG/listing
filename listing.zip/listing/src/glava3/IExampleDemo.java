package glava3;

// Интерфейс A
interface A {
    void metodA(); // метод А() интерфейса A
} // A interface

// Интерфейс B, наследующийся от A
interface B extends A {
    void metodB(); // метод В() интерфейса В
} // B interface

// Класс IExample, реализующий интерфейс B
class IExample implements B {
    public void metodA() {
        System.out.println("Метод A");
    }

    public void metodB() {
        System.out.println("Метод B");
    }
} // IExample class

// Демонстрационный класс IExampleDemo
public class IExampleDemo {
    public static void main(String[] args) {
        IExample ie = new IExample();
        ie.metodA(); // вызов метода интерфейса A
        ie.metodB(); // вызов метода интерфейса B
    } // main(String[]) method
} // IExampleDemo class
