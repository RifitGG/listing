package glava3;

class ParaByValue {
    void callByVal(int x, int y) {
        x = x + y;
        y = y + x;
        System.out.println("x = " + x);
        System.out.println("y = " + y);
    } // callByVal(int, int) метод
} // ParaByValue класс

class ParaByValueDemo {
    public static void main(String[] args) {
        int a = 2;
        int b = 3;
        // передача параметров по значению
        ParaByValue test = new ParaByValue();
        test.callByVal(a, b);
        System.out.println("a = " + a); // вывод 2
        System.out.println("b = " + b); // вывод 3
    } // main(String[]) метод
} // ParaByValueDemo класс
