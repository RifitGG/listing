package glava3;

class Vehicle2 {
    int passengers; // количество пассажиров
    int wheels; // количество колес
    int maxspeed; // максимальная скорость
    int burnup; // расход топлива
} // Vehicle class

class MoreVehiclesDemo {
    public static void main(String[] args) {
        // объект carl
        Vehicle carl = new Vehicle();
        carl.passengers = 2;
        carl.wheels = 6;
        carl.maxspeed = 130;
        carl.burnup = 30;

        // другой экземпляр класса Vehicle: объект busl
        Vehicle busl = new Vehicle();
        busl.passengers = 45;
        busl.wheels = 4;
        busl.maxspeed = 100;
        busl.burnup = 45;

        // расчет пути, пройденного за 1.25 часа
        double interval = 1.25;
        double distanceCar = carl.maxspeed * interval;
        double distanceBus = busl.maxspeed * interval;

        System.out.print("carl может проехать за 1 час 15 мин. расстояние в ");
        System.out.println(distanceCar + " км с " + carl.passengers + " пассажирами.");

        System.out.print("busl может проехать за 1 час 15 мин. расстояние в ");
        System.out.println(distanceBus + " км с " + busl.passengers + " пассажирами.");
    } // main(String[]) method
} // MoreVehiclesDemo class
