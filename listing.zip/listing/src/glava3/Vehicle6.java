package glava3;

class Vehicle6 {
    int passengers; // количество пассажиров
    int wheels; // число колес
    int maxspeed; // максимальная скорость
    int burnup; // расход топлива

    // Конструктор
    Vehicle6(int passengers, int wheels, int maxspeed, int burnup) {
        this.passengers = passengers;
        this.wheels = wheels;
        this.maxspeed = maxspeed;
        this.burnup = burnup;
    } // Vehicle конструктор

    // Расчет пройденного пути
    double distance(double interval) {
        double value = this.maxspeed * interval;
        return value;
    } // distance(double) метод
} // Vehicle класс
