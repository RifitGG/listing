package glava3;

class ParaByRef {
    int x, y;

    // Конструктор ParaByRef
    ParaByRef(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Передача объекта (по ссылке)
    void callByRef(ParaByRef o) {
        o.x = o.x + this.x;
        o.y = o.y + this.y;
    }
} // ParaByRef класс

class ParaByRefDemo {
    public static void main(String[] args) {
        ParaByRef p = new ParaByRef(2, 3); // первый объект
        ParaByRef q = new ParaByRef(3, 2); // второй объект
        System.out.println("p.x = " + p.x); // вывод 2
        System.out.println("p.y = " + p.y); // вывод 3
        p.callByRef(q);
        System.out.println("q.x = " + q.x); // вывод 5
        System.out.println("q.y = " + q.y); // вывод 5
    } // main(String[]) метод
} // ParaByRefDemo класс
