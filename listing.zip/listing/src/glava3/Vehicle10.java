package glava3;

class Vehicle10 {
    double speed; // скорость
    int wheels; // количество колес

    // Конструктор без параметров
    Vehicle10() {
        speed = 0;
        wheels = 4;
    }

    // Метод для вычисления пройденного расстояния
    double distance(double time) {
        return speed * time;
    }

    // Метод для получения максимальной скорости
    double getMaxSpeed() {
        return 150; // Примерное значение максимальной скорости
    }
} // Vehicle class

// Подкласс Auto, наследующий от класса Vehicle
class Auto extends Vehicle {
    public int speed;
    boolean sunroof; // наличие люка

    // Конструктор подкласса
    Auto() {
        super(); // Вызов конструктора базового класса
        sunroof = false; // По умолчанию люк отсутствует
    }

    public void getMaxSpeed() {
    }
} // Auto class

// Демонстрационный класс с методом main
public class ExtendsVehicleDemo {
    public static void main(String[] args) {
        // Создание объекта подкласса Auto
        Auto bmw = new Auto();
        bmw.sunroof = true; // Установка наличия люка
        bmw.speed = 90; // Установка скорости

        // Пример обращения к методам и переменным базового класса и подкласса
        System.out.println("Путь, пройденный за 1.5 часа: " + bmw.distance(1.5) + " км.");
        System.out.println("Максимальная скорость: " + bmw.getMaxSpeed() + " км/ч.");
        System.out.println("Наличие люка: " + bmw.sunroof);
    } // main(String[]) method
} // ExtendsVehicleDemo class
