package glava3;

class Vehicle {
    int passengers; // количество пассажиров
    int wheels; // количество колес
    int maxspeed; // максимальная скорость
    int burnup; // расход топлива

    public Vehicle(int i, int i1, int i2, int i3) {

    }

    public Vehicle() {

    }

    public Vehicle(int p, int w, int m, double b) {
    }

    public double distance(double time) {
        return time;
    }

    public void getMaxspeed() {
    }
} // Vehicle class

class VehicleDemo {
    public static void main(String[] args) {
        Vehicle carl = new Vehicle();
        carl.passengers = 2; // два пассажира
        carl.wheels = 6; // шесть колес
        carl.maxspeed = 130; // max. скорость 130 км/ч
        carl.burnup = 30; // расход топлива 30 литров на 100 км
        // расчет пути, проходимого за полчаса при движении с максимальной скоростью
        double distance = carl.maxspeed * 0.5;
        System.out.print("За полчаса carl может проехать ");
        System.out.println(distance + " км.");
        carl = null;
    } // main(String[]) method
} // VehicleDemo class
