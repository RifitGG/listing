package glava3;

class Vehicle7 {
    int passengers; // количество пассажиров
    int wheels; // число колес
    private int maxspeed; // максимальная скорость
    int burnup; // расход топлива

    // Конструктор класса Vehicle
    Vehicle7(int passengers, int wheels, int maxspeed, int burnup) {
        this.passengers = passengers;
        this.wheels = wheels;
        this.maxspeed = maxspeed;
        this.burnup = burnup;
    } // Vehicle(int, int, int, int) конструктор

    // Расчет пройденного пути
    double distance(double interval) {
        double val = this.maxspeed * interval;
        return val;
    } // distance(double) метод

    // Добавленный метод для доступа к maxspeed
    int getMaxspeed() {
        return this.maxspeed;
    }
} // Vehicle класс

class VehicleAccessDemo {
    public static void main(String[] args) {
        Vehicle ferrari = new Vehicle(2, 4, 360, 12);
        double distance = ferrari.distance(0.5);
        System.out.println("Ferrari за полчаса проедет " + distance + " км.");

        // Исправление ошибки доступа к приватной переменной maxspeed
        System.out.println("Скорость Ferrari: " + ferrari.getMaxspeed() + " км/ч");
    } // main(String[]) метод
} // VehicleAccessDemo класс
