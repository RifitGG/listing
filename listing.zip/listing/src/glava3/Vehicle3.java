package glava3;

class Vehicle3 {
    int passengers; // количество пассажиров
    int wheels; // количество колес
    int maxspeed; // максимальная скорость
    int burnup; // расход топлива

    // объявляем метод, вычисляющий пройденный путь
    // метод принимает параметр interval, задающий время,
    // и не возвращает никакого значения (void)
    void distance(double interval) {
        double value = maxspeed * interval;
        System.out.println("Пройдет путь, равный " + value + " км.");
    } // distance(double interval)
} // Vehicle class

class VehicleMethodDemo {
    public static void main(String[] args) {
        Vehicle car = new Vehicle();
        car.passengers = 2;
        car.wheels = 4;
        car.maxspeed = 130;
        car.burnup = 30;

        // другой экземпляр класса Vehicle
        Vehicle bus = new Vehicle();
        bus.passengers = 45;
        bus.wheels = 4;
        bus.maxspeed = 100;
        bus.burnup = 25;

        // расчет пути, пройденного за 0.5 часа
        double time = 0.5;

        System.out.print("Автомобиль с " + car.passengers + " пассажирами ");
        car.distance(time);
        System.out.print("Автобус с " + bus.passengers + " пассажирами ");
        bus.distance(time);
    } // main(String[]) method
} // VehicleMethodDemo class
