package glava3;

class Vehicle8 {
    int passengers; // количество пассажиров
    private int wheels; // число колес
    private int maxspeed; // максимальная скорость
    int burnup; // расход топлива

    // Конструктор без параметров, инициализирующий переменные объекта стандартными значениями
    Vehicle8() {
        this.passengers = 4;
        this.wheels = 4;
        this.maxspeed = 160;
        this.burnup = 13;
    } // Vehicle() конструктор

    // Конструктор с параметрами, инициализирующий переменные объекта значениями, переданными из вызывающей программы
    Vehicle8(int passengers, int wheels, int maxspeed, int burnup) {
        this.passengers = passengers;
        this.wheels = wheels;
        this.maxspeed = maxspeed;
        this.burnup = burnup;
    } // Vehicle(int, int, int, int) конструктор
} // Vehicle класс
