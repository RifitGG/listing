package glava3;

// Базовый класс Vehicle
class Vehicle {
    // Поля класса
    int passengers; // количество пассажиров
    int wheels; // количество колес
    int maxspeed; // максимальная скорость
    double burnup; // расход топлива

    // Конструктор по умолчанию
    Vehicle() {
        // Инициализация полей значениями по умолчанию
        passengers = 0;
        wheels = 0;
        maxspeed = 0;
        burnup = 0.0;
    }

    // Переопределенный метод toString()
    public String toString() {
        return "Vehicle(passengers=" + passengers + ";" +
                "wheels=" + wheels + ";" +
                "maxspeed=" + maxspeed + ";" +
                "burnup=" + burnup + ")";
    }
} // class Vehicle

// Подкласс Auto, наследующий от класса Vehicle
class Auto extends Vehicle {
    boolean sunroof; // наличие люка

    // Конструктор подкласса с одним параметром
    Auto(boolean sunroof) {
        // Вызов конструктора суперкласса с параметрами по умолчанию
        super();
        this.sunroof = sunroof;
    }
} // class Auto

// Демонстрационный класс PolyVehicleDemo
class PolyVehicleDemo {
    public static void main(String[] args) {
        Auto a = new Auto(true); // экземпляр подкласса Auto
        Vehicle v = new Vehicle(); // экземпляр класса Vehicle

        // поместим оба объекта в массив типа Vehicle
        Vehicle[] pvd = {a, v}; // Исправлено имя массива

        for (int i = 0; i < pvd.length; i++) {
            // динамический выбор версии переопределенного метода toString()
            System.out.println(pvd[i].toString());
        } // for
    } // main(String[]) method
} // PolyVehicleDemo class
