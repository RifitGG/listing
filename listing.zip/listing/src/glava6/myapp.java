package glava6;

import java.io.*;

public class myapp {
    public static void main(String[] args) {
        try {
            PrintStream errOut = new PrintStream(new FileOutputStream("Error.log"));
            System.setErr(errOut);
            PrintStream sysOut = new PrintStream(new FileOutputStream("Debug.log"));
            System.setOut(sysOut);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Сообщение о нормальной работе программы");
        System.err.println("Сообщение об ошибках");
    } // main(String[]) method
} // MyApp class
