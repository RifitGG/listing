package glava6;

import java.io.PrintStream;

public class ShortcutOutDemo {
    // объявление статического члена типа PrintStream
    private static PrintStream out = System.out;

    public static void main(String[] args) {
        // применение сокращенной формы записи
        out.println("Пример...");
        start();
    }

    static void start() {
        String level = System.getProperty("java.version", "beginner");
        out.println("Уровень: " + level);
    }
}
