package glava6;

import java.io.*;

public class ReadInput {
    private String cmd;
    private Process proc;
    private InputStream input;
    private BufferedReader in;

    // Конструктор класса glava6.ReadInput может вызвать исключение IOException
    public ReadInput(String cmd) throws IOException {
        this.cmd = cmd;
        // Запуск процесса, заданного именем исполняемого файла
        proc = Runtime.getRuntime().exec(cmd);
        // Перехват его потока вывода
        input = proc.getInputStream();
        in = new BufferedReader(new InputStreamReader(input));
    }

    // Метод, считывающий очередную строку вывода процесса
    public String readLine() throws IOException {
        String line;
        do {
            line = in.readLine();
        } while (line != null && (line.equals("\r") || line.isEmpty()));
        return line;
    }

    // Закрытие запущенной программы
    public void close() {
        try {
            in.close();
            input.close();
            proc.destroy();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } finally {
            in = null;
            input = null;
            proc = null;
        }
    }

    public static void main(String[] args) {
        String cmd = "ping localhost";
        if (args.length > 0) {
            cmd = args[0];
        }

        try (ReadInput ri = new ReadInput(cmd)) {
            String line;
            // Вывод каждой строки на экран
            while ((line = ri.readLine()) != null) {
                if (!line.equals("\r")) {
                    System.out.println("java:> " + line);
                }
            }
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }
}
