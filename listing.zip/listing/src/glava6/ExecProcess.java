package glava6;

import java.io.*;

public class ExecProcess {
    private PrintStream ps;
    private OutputStreamWriter osw;
    private BufferedWriter bw;
    private PrintWriter pw;

    // Конструктор RusPrintWriter(PrintStream) может вызвать исключение UnsupportedEncodingException
    public RusPrintWriter(PrintStream ps) throws UnsupportedEncodingException {
        this.ps = ps;
        try {
            osw = new OutputStreamWriter(ps, "Cp852");
            bw = new BufferedWriter(osw);
            pw = new PrintWriter(bw, true);
        } catch (UnsupportedEncodingException uee) {
            // Обработка исключения
            throw uee;
        } finally {
            // Очистка ресурсов не требуется, так как они будут закрыты в методе close()
        }
    }

    // Метод для вывода строк
    public void println(String line) {
        if (pw != null) {
            pw.println(line);
        } else {
            ps.println(line);
        }
    }

    // Метод для закрытия ресурсов
    public void close() {
        if (pw != null) {
            pw.close();
        }
        // Остальные ресурсы будут закрыты автоматически
    }
}
