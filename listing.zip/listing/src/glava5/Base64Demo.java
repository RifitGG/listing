package glava5;

import java.util.Base64;

public class Base64Demo {
    public static void main(String[] args) {
        // программа должна быть запущена по крайней мере с одним параметром —
        // строкой, подлежащей шифрованию
        if (args.length == 0) {
            System.out.println("usage: glava5.Base64Demo text");
            System.exit(1);
        }

        // кодирование текста
        String text = args[0];
        String encoded = Base64.getEncoder().encodeToString(text.getBytes());

        // декодирование текста
        String decoded = new String(Base64.getDecoder().decode(encoded));

        // вывод результатов
        System.out.println("Закодировано: " + encoded);
        System.out.println("Декодировано: " + decoded);
    } // main(String[]) method
} // glava5.Base64Demo class
