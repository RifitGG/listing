package glava5;

public class Stack {
    private Object[] theArray;
    private int topOfStack;
    static final int DEFAULT_CAPACITY = 10;

    public Stack() {
        theArray = new Object[DEFAULT_CAPACITY];
        topOfStack = -1;
    } // glava5.Stack constructor

    public boolean isEmpty() {
        return topOfStack == -1;
    } // isEmpty() method

    public Object top() {
        if (isEmpty())
            return null;
        return theArray[topOfStack];
    } // top() method

    public void pop() {
        if (isEmpty())
            return;
        topOfStack--;
    } // pop() method

    public Object topAndPop() {
        if (isEmpty())
            return null;
        return theArray[topOfStack--];
    } // topAndPop() method

    public void push(Object x) {
        if (topOfStack + 1 == theArray.length)
            doubleArray();
        theArray[++topOfStack] = x;
    } // push(Object) method

    public void makeEmpty() {
        topOfStack = -1;
    } // makeEmpty() method

    private void doubleArray() {
        Object[] newArray = new Object[theArray.length * 2];
        System.arraycopy(theArray, 0, newArray, 0, theArray.length);
        theArray = newArray;
    } // doubleArray() method
} // glava5.Stack class
