package glava5;

class QuickSort {
    static void sort(char[] items) {
        quicksort(items, 0, items.length - 1);
    } // sort(char[])

    private static void quicksort(char[] items, int left, int right) {
        int i = left, j = right;
        char pivot = items[(left + right) / 2];
        char temp;

        while (i <= j) {
            while (items[i] < pivot) i++;
            while (items[j] > pivot) j--;
            if (i <= j) {
                temp = items[i];
                items[i] = items[j];
                items[j] = temp;
                i++;
                j--;
            }
        }

        if (left < j)
            quicksort(items, left, j);
        if (i < right)
            quicksort(items, i, right);
    } // quicksort(char[], int, int)
} // glava5.QuickSort class

class QuickSortDemo {
    public static void main(String[] args) {
        char[] seq = {'h', 'e', 'a', 'a', 'c', '1'};
        System.out.print("Исходный порядок символов: ");
        for (char c : seq)
            System.out.print(c + " ");
        System.out.println();

        QuickSort.sort(seq);
        System.out.print("Сортированный порядок: ");
        for (char c : seq)
            System.out.print(c + " ");
        System.out.println();
    } // main(String[]) method
} // glava5.QuickSortDemo class
