package glava5;

class Queue {
    private char[] q; // массив для хранения элементов очереди
    private int putloc, getloc; // индексы для вставки и извлечения элементов очереди

    // Конструктор для создания пустой очереди заданного размера
    Queue(int size) {
        q = new char[size + 1]; // резервирование памяти
        putloc = getloc = 0;
    }

    // Конструктор для создания очереди на основе другой очереди
    Queue(Queue ob) {
        putloc = ob.putloc;
        getloc = ob.getloc;
        q = new char[ob.q.length];
        // копирование элементов из предыдущей очереди
        System.arraycopy(ob.q, 0, q, 0, ob.q.length);
    }

    // Конструктор для создания очереди на основе массива символов
    Queue(char a[]) {
        putloc = 0;
        getloc = 0;
        q = new char[a.length + 1];
        // копирование элементов символьного массива в очередь
        for (char ch : a) {
            put(ch);
        }
    }

    // Метод для проверки переполнения очереди
    boolean isFull() {
        return (putloc == q.length - 1);
    }

    // Метод для проверки пустоты очереди
    boolean isEmpty() {
        return (getloc == putloc);
    }

    // Метод для добавления символа в очередь
    void put(char ch) {
        if (isFull()) {
            throw new IllegalStateException("Очередь переполнена.");
        }
        q[putloc++] = ch;
    }

    // Метод для извлечения символа из очереди
    char get() {
        if (isEmpty()) {
            throw new IllegalStateException("Очередь пуста.");
        }
        return q[getloc++];
    }
}
