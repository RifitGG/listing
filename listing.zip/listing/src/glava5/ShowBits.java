package glava5;

import java.io.PrintStream;

public class ShowBits {
    private int numbits; // количество битов для отображения

    public ShowBits(int numbits) {
        this.numbits = numbits;
    }

    public String getBinaryForm(long val) {
        long mask = 1;
        String form = "";
        mask <<= numbits - 1;
        int spacer = 0;
        for (; mask != 0; mask >>>= 1) {
            form += (val & mask) != 0 ? "1" : "0"; // бит включен или выключен
            spacer++;
            if (spacer % 8 == 0) {
                form += " ";
                spacer = 0;
            }
        }
        return form;
    } // getBinaryForm(long) method

    public void show(long val, PrintStream out) {
        String binaryForm = getBinaryForm(val);
        out.println(binaryForm);
    } // show(long, PrintStream) method
} // glava5.ShowBits class
