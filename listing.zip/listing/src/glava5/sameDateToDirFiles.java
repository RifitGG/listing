import java.io.File;

public static void sameDateToDirFiles(String dir) {
    long modified = System.currentTimeMillis(); // текущее время (миллисекунды)

    File walkDir = new File(dir); // просматриваемая папка
    String[] dirList = walkDir.list(); // список элементов в папке
    if (dirList == null) return; // Если dirList равен null, выходим из метода

    // последовательный просмотр папки
    for (int i = 0; i < dirList.length; i++) {
        File f = new File(walkDir, dirList[i]); // Создаем объект File с полным путем
        if (f.isDirectory()) {
            // элемент является также каталогом, осуществляется рекурсивный вызов метода
            sameDateToDirFiles(f.getPath());
            continue;
        }
        // для файлов устанавливаем дату последнего изменения
        f.setLastModified(modified);
    } // for (int i = 0; i < dirList.length; i++)
} // glava5.(String)

public void main() {
}
